
devtools::load_all()

library(DHSClogger)

log <- get_dhsc_logger()
log$info("This is a test")
log$get_log_names()

log$set_threshold("log.console", log$WARN)
log$warn("This is a test")
